<?php
$lan=$_SERVER["HTTP_ACCEPT_LANGUAGE"];
$ml=explode(';',$lan);
$lga='EN';
$tit='Please, don\'t attack this site.';
$tl=explode(',',$ml[0]);
$tl[0]=' '.$tl[0];
$tl[1]=' '.$tl[1];
if(strpos($tl[0],'zh')||strpos($tl[1],'zh')){
  $lga='CN';
  $tit='哥别攻击行不行';
}else{
  $lga='EN';
}
?>
<!DOCTYPE html>
<html>
  <head>
    <title><? echo $tit; ?></title>
  </head>
  <body>
    <? if($lga=='CN'): ?>
    <p>
      你好，这位黑客：<br/><br>
      别来无恙啊。<br><br>
      我是这个网站的管理者。你知道这里是什么，WordPress管理员的登录地址。<br><br>
      我知道，你想攻击这个网站，但是很遗憾...<br>
      第一，这个网站有完整的备份。删库勒索？还是别想了。<br>
      第二，这不是我的服务器，域名也套了CloudFlare。<br>
      第三，登录页面完全在另一个地方。你是不是真的认为这是wordpress搭建的？<br>
      最后，别试图用Tor或者境外代理访问网站。<br><br>
      我知道您也缺钱，但是哥，搭建这个博客我一分钱没花，换个网站吧qwq<br><br>
      此致<br>
      Tortoise-God(站长) & HelloOSMe(技术支持)<br>
    </p>
    <? else: ?>
    <p>
      Dear the hacker,<br/><br>
      Hi!<br><br>
      I am the admin of this site. You know this is Wordpress's login address.<br><br>
      I know you want to attact, but...<br>
      Firstly, the site has been archived. Are you trying to blackmail me by deleting the database?<br>
      Secondly, this is not my server but is replit's. It protects by CloudFlare. <br>
      Thirdly, the login page isn't here. This site didn't build by WordPress.<br>
      At last, don't trying to use TOR.<br><br>
      I know you're also short of money, but sir, I didn't spend a penny building this blog. Let's switch to a different website...<br><br>
      Yours,<br>
      Tortoise-God(Owner) & HelloOSMe(support)<br>
    </p>
    <? endif; ?>
  </body>
</html>