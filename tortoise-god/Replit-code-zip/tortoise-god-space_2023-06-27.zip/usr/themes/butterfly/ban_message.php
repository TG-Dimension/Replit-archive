<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
function show_ban_message($title,$value){
$msg=<<<BANMESSAGE
<!DOCTYPE html>
<html>
  <head>
    <link rel="icon" href="/img/tg.jpeg">
    <link rel="stylesheet" href="/css/style.css">
    <link rel="stylesheet" href="/css/grid.css">
    <title>403 Forbidden</title>
<style>
  a.jmp{display: inline-block;
    text-align: center;
    border: 0.9px solid #aaa;
    border-radius: 2.5px;
    background: #fff;
    color: #000;
    width: 80px;
    padding: 4px 0;
    margin: 0 5px;
    font-size: 90%;
    cursor: default;
    -moz-user-select: none;
    -webkit-user-select: none;
    -ms-user-select: none;
    -khtml-user-select: none;
    user-select: none;
  }
  a.jmp:hover{
    border-color: #0078d4;
    background: #e0eef9;
  }
  a.jmp:active{
        border-color: #005499;
    background: #CCE4F7;
  }
</style>
</head>
<body>
  <div id="box"><div class="center">
  <img alt="LOGO" src="/img/tg.jpeg" class="logo">
  <h1>$title</h1>
  <p>$value</p>
</div>
</body></html>
BANMESSAGE;
echo $msg;
} 
?>