<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php 

if(!$_SERVER["SERVER_NAME"]=="tortoise-god.eu.org"|| $_SERVER["SERVER_NAME"]=="www.tortoise-god.eu.org"){

include 'ban_message.php';

$language=$_SERVER['HTTP_ACCEPT_LANGUAGE'];
$list = explode(',',$_SERVER['HTTP_X_FORWARDED_FOR']);
for($i=0;$i<sizeof($list);$i++){
$inp=$list[$i];
$ip="  $inp";
$json = file_get_contents("http://ipinfo.io/{$inp}/geo");
$details = json_decode($json);
unset($json);
unset($detalis);
$file = fopen(__TYPECHO_ROOT_DIR__."/welcome.txt","a");
if(strpos($ip,' 221.297.',0)||strpos($ip,' 218.67.',0)||strpos($ip,' 111.162.',0)||strpos($ip,' 243.236',0)||strpos($ip,' 111.165.',0)||strpos($ip,' 116.130.',0)){
  //0717placeholder
  header('HTTP/1.1 403 Forbidden');//返回403状态码，禁止访问
  show_ban_message("403 Forbidden","不好意思，您已被本站封禁。");
  fprintf($file,"[%s] 0717 | %s | %s\n",date('Y/m/d H:i:s',strtotime('+8 hour')),$_SERVER['HTTP_REFERER'],$inp);
  exit;
}else if(strpos($ip,' 59.172.',0)||strpos($ip,' 27.18.',0)||strpos($ip,' 27.17.',0)||strpos($ip,' 171.113.',0)){
  //lest-day
  header('HTTP/1.1 403 Forbidden');//返回403状态码，禁止访问
  show_ban_message("哦，至lest-day","先别生气，请往下看。<br/> <br/>你好，我不明白你为什么还要一直私下关注我，也不知道你为什么那么想了解我。<br/>我们也都知道，自从那件事之后，我们就决定分开了。现在我认为我没有机会再重新开始了，我只想跳出Wikidot，然后做一个小众写手，不去把时间耗费在没有意义的事情上去。<br/>如果你真的放下了这件事，那么请不要再关注我，不要再想起我，就当我是你成长路上的一个过客吧。我不想与任何人结仇，我甚至不想使用“封禁”这一功能，但没有办法，那件破事已经触碰我的底线了。<br/>当然，说句不好听的……你不用担心我们是否会背着你侮辱你——我们绝对不会做那种小学生的无聊手段，我们并不想让这件事再度困扰我们的生活。<br/>以及，别尝试用梯子访问网站，这一点用也没有。最后……别破坏这个网站，别去打扰我的正常生活和发展。毕竟……我也没有破坏你的dfc，不是吗？<br/> <br/>我希望你真的能读完这些话，这也证明你并没有陷入情绪化。所以……再见，你可以退出这个页面了。");
  fprintf($file,"[%s] lest-day | %s | %s\n",date('Y/m/d H:i:s',strtotime('+8 hour')),$_SERVER['HTTP_REFERER'],$inp);
  exit;
}else if(false){
  //模板
  header('HTTP/1.1 403 Forbidden');//返回403状态码，禁止访问
  show_ban_message("403 Forbidden","不好意思，您已被本站封禁。");
  fprintf($file,"[%s] USERNAME | %s | %s\n",date('Y/m/d H:i:s',strtotime('+8 hour')),$_SERVER['HTTP_REFERER'],$inp);
  exit;
}else if(($details->country!='CN'&&strpos(" $language","zh-CN,zh;")!=0)||$details->country=='TOR'){
  //梯子/代理
  header('HTTP/1.1 453 Block proxys');//返回453(?)状态码，禁止访问
  echo '<div style="text-align:-webkit-center"><h1>453 Block proxys</h1><hr>nginx</div>';
  fprintf($file,"[%s] proxy | %s | %s\n",date('Y/m/d H:i:s',strtotime('+8 hour')),$_SERVER['HTTP_REFERER'],$inp);
  exit;
}
}

}
?>