<html><head><link rel="icon" href="/img/tg.jpeg"><link rel="stylesheet" href="./css/style.css"><link rel="stylesheet" href="./css/grid.css"><title>第三方链接跳转</title>
<style>
  a.jmp{display: inline-block;
    text-align: center;
    border: 0.9px solid #aaa;
    border-radius: 2.5px;
    background: #fff;
    color: #000;
    width: 80px;
    padding: 4px 0;
    margin: 0 5px;
    font-size: 90%;
    cursor: default;
    -moz-user-select: none;
    -webkit-user-select: none;
    -ms-user-select: none;
    -khtml-user-select: none;
    user-select: none;
  }
  a.jmp:hover{
    border-color: #0078d4;
    background: #e0eef9;
  }
  a.jmp:active{
        border-color: #005499;
    background: #CCE4F7;
  }
</style>
</head><body><div id="box"><div class="center"><img alt="LOGO" src="./img/tg.jpeg" class="logo">
  <?php if(!isset($_SERVER['QUERY_STRING'])||!$_SERVER['QUERY_STRING']): ?>
  <h1>URL错误</h1>
  <p>请注意，您的URL值为空，我们无法将您重定向到网站。</p>
  <?php exit; ?>
  <? endif; ?>
<?php
$list=explode('&',$_SERVER['QUERY_STRING']);
$ntb=false;
$url='';
if($list[0]=='newtab'){
  $ntb=true;
  $url=$list[1];
}else if($list[0]=='danger'){
  echo '<h1 style="color:#c11;">此网站不安全！</h1>';
  echo "地址:<span style=\"color:#c11;\">$list[1]</span>";
  echo '<p>此网站可能包含恶意攻击程序，您应该立即返回上一页！</p><div class="center">';
  echo '<a onclick="history.go(-1);" class="jmp">返回</a></div>';
  exit;
}else{
  $url=$list[0];
}
?>
  <h1>您将要跳转到第三方网站</h1>
  <p>您即将离开TG的次元空间，前往以下网站:<br/><span style="color:#0055ff"><?php echo $url; ?></span></p>
  <h3>您要继续吗？</h3></div><div class="center">
<?php if(!$ntb){
  echo '<a onclick="history.go(-1);" class="jmp">返回</a>';
}
?><a class="jmp" href="<?php echo $url; ?>">前进</a></div>
</div>
</body></html>