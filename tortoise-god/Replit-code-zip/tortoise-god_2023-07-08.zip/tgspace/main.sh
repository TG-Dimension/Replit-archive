nohup php -S 0.0.0.0:29292 -t . >/dev/null &
