function check_links(){
    var a=document.getElementsByTagName('a');
    for(var i=0;i<a.length;i++){
        if(a[i].href.includes(window.location.host)||a[i].href.includes('helloos.eu.org')||a[i].href.includes('tortoise-god.wikidot.com')){continue;}
        if(a[i].href.includes('deep-forest-club.wikidot.com')||a[i].href.includes('ld-privte-website.wikidot.com')||a[i].href.includes('wikiunion')||a[i].href.includes('scr')||a[i].href.includes('esu')){a[i].href='/jump.php?danger&'+a[i].href;continue;}
	if(a[i].href&&!a[i].href.includes('mailto:')){
            if(a[i].target.includes('blank')||a[i].target.includes('BLANK')){
                a[i].href='/jump.php?newtab&'+a[i].href;
                continue;
            }else{
	        a[i].href='/jump.php?'+a[i].href;
            continue;
            }
	}
    }
}
document.addEventListener('copy', function (event) {
    let clipboardData = event.clipboardData || window.clipboardData;
    if (!clipboardData) { return; }
    let text = window.getSelection().toString();
    let add = "\n----------\n除非特别声明，本文采用CC-BY-SA-4.0协议，转载时请附上作者和原文链接。\n作者：Tortoise-God\n原文："+window.location.href;
    if (text) {
        event.preventDefault();
        clipboardData.setData('text/plain', text + add);
        document.querySelector('#result').innerText = text + add;
    }
});
window.onload=function(){
  check_links();
  console.log(`%c
   ###########     #######     
        #        ##            
        #        #             
        #        #     ####    
        #        ##      ##    
        #          ######      
%c            次元空间            
Copyright (C) 2023 Tortoise-God
`,"color:#000;background:#fff;","background:#aaa;color:#000;");
}